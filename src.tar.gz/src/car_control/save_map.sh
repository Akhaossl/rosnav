#!/bin/bash

rosrun map_server map_saver -f  /home/test/workplace/src/car_control/map/mymap

